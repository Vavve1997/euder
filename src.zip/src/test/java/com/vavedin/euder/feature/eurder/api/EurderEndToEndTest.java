package com.vavedin.euder.feature.eurder.api;

import com.vavedin.euder.feature.eurder.domain.EurderDatabase;
import com.vavedin.euder.feature.item.domain.*;
import com.vavedin.euder.feature.user.domain.*;
import com.vavedin.euder.feature.security.PasswordEncoder;
import com.vavedin.euder.feature.security.enums.Role;
import io.restassured.response.Response;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.annotation.*;

import java.math.BigDecimal;
import java.time.*;
import java.util.*;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.*;
import static org.hamcrest.Matchers.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Import(EurderEndToEndTest.FixedTime.class)
class EurderEndToEndTest {
    @TestConfiguration
    static class FixedTime {
        @Bean
        @Primary
        Clock storyThreeTestClock() {
            return Clock.fixed(Instant.parse("2026-10-20T10:00:00Z"), ZoneId.of("Europe/Brussels"));
        }
    }

    @LocalServerPort
    private int port;
    @Autowired
    private UserDatabase users;
    @Autowired
    private ItemDatabase items;
    @Autowired
    private EurderDatabase eurders;
    @Autowired
    private PasswordEncoder encoder;
    private String userId, email, itemA, itemB;
    private final List<String> createdEurders = new ArrayList<>();

    @BeforeEach
    void setup() {
        userId = UUID.randomUUID().toString();
        email = userId + "@example.com";
        users.getUserDatabase().put(userId, new User("Test", "User", email,
                new Address("Street", 1, 1000, "City"), "012345", userId, Role.MEMBER, encoder.encode("Secret123!")));
        itemA = UUID.randomUUID().toString();
        itemB = UUID.randomUUID().toString();
        items.getItemDatabase().put(itemA, new Item("Coffee", "Good coffee", new BigDecimal("89.95"), 3, itemA));
        items.getItemDatabase().put(itemB, new Item("Toaster", "Toasts bread", new BigDecimal("29.95"), 0, itemB));
    }

    @AfterEach
    void cleanup() {
        users.getUserDatabase().remove(userId);
        items.getItemDatabase().remove(itemA);
        items.getItemDatabase().remove(itemB);
        createdEurders.forEach(eurders.getEurderDatabase()::remove);
    }

    private Response post(List<Map<String, Object>> groups, boolean authenticate) {
        var request = given().baseUri("http://localhost").port(port).contentType("application/json")
                .body(Map.of("itemGroups", groups));
        if (authenticate) request.auth().preemptive().basic(email, "Secret123!");
        return request.when().post("/eurders");
    }

    @Test
    void memberOrdersMultipleItems_andReceivesTotalAndShippingDates() {
        Response response = post(List.of(Map.of("itemId", itemA, "amount", 3), Map.of("itemId", itemB, "amount", 2)), true);
        if (response.statusCode() == 201) createdEurders.add(response.jsonPath().getString("id"));
        response.then().statusCode(201).contentType("application/json")
                .body("customerId", equalTo(userId))
                .body("itemGroups.size()", equalTo(2))
                .body("itemGroups[0].itemId", equalTo(itemA))
                .body("itemGroups[0].amount", equalTo(3))
                .body("itemGroups[0].shippingDate", equalTo("2026-10-21"))
                .body("itemGroups[1].itemId", equalTo(itemB))
                .body("itemGroups[1].shippingDate", equalTo("2026-10-27"));
        assertThat(new BigDecimal(response.jsonPath().getString("totalPrice"))).isEqualByComparingTo("329.75");
        String id = response.jsonPath().getString("id");
        assertThat(id).isNotBlank();
        var saved = eurders.getEurderDatabase().get(id);
        assertThat(saved).isNotNull();
        assertThat(saved.getCustomerId()).isEqualTo(userId);
        assertThat(saved.getItemGroups()).hasSize(2);
        assertThat(saved.calculateTotalPrice()).isEqualByComparingTo("329.75");
    }

    @Test
    void missingAuthentication_returns401WithoutSaving() {
        var before = new HashMap<>(eurders.getEurderDatabase());
        post(List.of(Map.of("itemId", itemA, "amount", 1)), false).then().statusCode(401)
                .header("WWW-Authenticate", startsWith("Basic "));
        assertThat(eurders.getEurderDatabase()).containsExactlyInAnyOrderEntriesOf(before);
    }

    @Test
    void unknownItem_returns400WithoutSavingPartialEurder() {
        var before = new HashMap<>(eurders.getEurderDatabase());
        post(List.of(Map.of("itemId", itemA, "amount", 1), Map.of("itemId", "missing", "amount", 1)), true)
                .then().statusCode(400);
        assertThat(eurders.getEurderDatabase()).containsExactlyInAnyOrderEntriesOf(before);
    }

    @Test
    void emptyEurder_returns400WithoutSaving() {
        var before = new HashMap<>(eurders.getEurderDatabase());
        post(List.of(), true).then().statusCode(400);
        assertThat(eurders.getEurderDatabase()).containsExactlyInAnyOrderEntriesOf(before);
    }
}
